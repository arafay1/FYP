import React from 'react'

const SendEmail = () => {
  return (
    <div>SendEmail</div>
  )
}

export default SendEmail