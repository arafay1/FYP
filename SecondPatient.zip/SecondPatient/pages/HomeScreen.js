import React from 'react'
import { View,Text,Image } from 'react-native'
import Categories from '../components/Categories'
import SingleUpcomingAppointment from '../components/SingleUpcomingAppointment'
import ViewSomeDoctors from '../components/ViewSomeDoctors'
import Fab from '@mui/material/Fab';
import AddIcon from '@mui/icons-material/Add';
import Chat from '../assets/chat.png'
import Video from '../assets/video.png'
import Tooltip from '@mui/material/Tooltip';

import { useNavigation } from '@react-navigation/native';
const HomeScreen = () => {
  const navigation = useNavigation();
  return (
    <View style={{margin:'10px',marginLeft:'60px',marginTop:'30px'}}>
      <Categories />
      <View style={{flexDirection:'row',gap:'50px',marginTop:'30px'}}>
      <SingleUpcomingAppointment />
      <ViewSomeDoctors />
      </View>
      <View style={{flexDirection:'row',justifyContent:'space-between'}}>
        <View style={{marginTop:'10px'}}>
          <Tooltip title="Chat">
            <Fab style={{backgroundColor:'black'}} aria-label="add" onClick={() => navigation.navigate('MyChatApp')}>
            <Image source={Chat} style={{width:'30px',height:'30px'}} />
            </Fab>
          </Tooltip>
          
        </View>
        <View style={{marginTop:'10px',marginRight:'50px'}}>
          <Tooltip title="Video Call">
            <Fab style={{backgroundColor:'black'}} aria-label="add" onClick={() => navigation.navigate('MyVideoCall')}>
            <Image source={Video} style={{width:'30px',height:'30px'}} />
            </Fab>
          </Tooltip>
          
        </View>
      </View>
      
      
    </View>
  )
}

export default HomeScreen