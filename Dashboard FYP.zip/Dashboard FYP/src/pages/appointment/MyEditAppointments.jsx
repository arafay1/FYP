import "./Appointments.scss"
import Sidebar from "../../components/sidebar/Sidebar"
import MyNavbar from "../../components/navbar/MyNavbar";
// import Datatable from "../../components/datatable/Datatable"

import EditSingleAppointments from "./EditSingleAppointments"
const MyEditAppointments = () => {


  return (
    <div className="list">
      <Sidebar/>
      <div className="listContainer">
        <MyNavbar/>
        <EditSingleAppointments />

      </div>
    </div>
  )
}

export default MyEditAppointments