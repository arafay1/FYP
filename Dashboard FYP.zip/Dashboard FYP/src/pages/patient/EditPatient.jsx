import "./patient.scss"
import Sidebar from "../../components/sidebar/Sidebar"
import MyNavbar from "../../components/navbar/MyNavbar";
// import Datatable from "../../components/datatable/Datatable"
import MyDatatable from "../../components/datatable/MyDatatable"
import EditSinglePatient from "./EditSinglePatient"
const EditPatient = () => {


  return (
    <div className="list">
      <Sidebar/>
      <div className="listContainer">
        <MyNavbar/>
        <EditSinglePatient />

      </div>
    </div>
  )
}

export default EditPatient