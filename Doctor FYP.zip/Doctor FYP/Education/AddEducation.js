// import "./Appointments.scss"
// import Datatable from "../../components/datatable/Datatable"

import AddSingleEducation from "./AddSingleEducation"
const AddEducation = () => {


  return (
    <div className="list">
      <div className="listContainer">
        {/* <Navbar/> */}
        <AddSingleEducation />
      </div>
    </div>
  )
}

export default AddAppointment