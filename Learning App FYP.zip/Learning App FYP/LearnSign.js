import { StyleSheet, Text, View,Image } from 'react-native'
import React from 'react'
const NestedScreen1 = ({route}) => {
  
  return (
    <View>
      <View style={styles.textcontainer}>
        <Text style={styles.mytext}>Learn Numbers</Text>
      </View>
      <View style={styles.maincontainer}>
        <View>
        
            
          <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/NumbersLearn/1.png')} />
          <Text style={{fontSize:50}}>
            1
          </Text>
          
        </View>
        <View>
          <Image style={{width: 350, height: 350, top:60}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/NumbersLearn/2.png')} />
          <Text style={{fontSize:50}}>
            2
          </Text>
        </View>
        <View>
          <Image style={{width: 400, height: 400,top:-10}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/NumbersLearn/3.png')} />
          <Text style={{fontSize:50}}>
            3
          </Text>
        </View>
       
      </View>

      <View style={styles.maincontainer}>
      
        <View>
          <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/4.png')} />
          <Text style={{fontSize:50}}>
            4
          </Text>
        </View>
        <View>
          <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/5.png')} />
          <Text style={{fontSize:50}}>
            5
          </Text>
        </View>
        <View>
          <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/6.png')} />
          <Text style={{fontSize:50}}>
            6
          </Text>
        </View>
      </View>  
      <View style={styles.maincontainer}>
        <View>
          <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/7.png')} />
          <Text style={{fontSize:50}}>
            7
          </Text>
        </View>
        <View>
          <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/8.png')} />
          <Text style={{fontSize:50}}>
            8
          </Text>
        </View>
        
        <View>
          <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/9.png')} />
          <Text style={{fontSize:50}}>
            9
          </Text>
        </View>
      </View>
      <View style={styles.maincontainer}>
          <View>
            <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/10.png')} />
            <Text style={{fontSize:50}}>
              10
            </Text>
          </View>
        </View>
      <View style={styles.sectextcontainer}>
      <Text style={styles.mytext}>Learn Alphabets</Text>
      </View>
      <View style={styles.maincontainer}>
        
        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/a.png')} />
          <Text>
            A
          </Text>
        </View>
        

        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/b.png')} />
          <Text>
            B
          </Text>
        </View>
        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/C.png')} />
          <Text>
            C
          </Text>
        </View>
        
        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/D.png')} />
          <Text>
            D
          </Text>
        </View>
        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/E.png')} />
          <Text>
            E
          </Text>
        </View>
        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/F.png')} />
          <Text>
            F
          </Text>
        </View>
        

        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/G.png')} />
          <Text>
            G
          </Text>
        </View>
        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/H.png')} />
          <Text>
            H
          </Text>
        </View>
        
        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/I.png')} />
          <Text>
            I
          </Text>
        </View>
        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/K.png')} />
          <Text>
            K
          </Text>
        </View>
        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/V.png')} />
          <Text>
            V
          </Text>
        </View>
        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/W.png')} />
          <Text>
            W
          </Text>
        </View>
        
      </View>

      <View style={styles.maincontainer}>
        
        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/L.png')} />
          <Text>
            L
          </Text>
        </View>
        

        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/M.png')} />
          <Text>
            M
          </Text>
        </View>
        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/N.png')} />
          <Text>
            N
          </Text>
        </View>
        
        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/O.png')} />
          <Text>
            O
          </Text>
        </View>
        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/P.png')} />
          <Text>
            P
          </Text>
        </View>
        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/Q.png')} />
          <Text>
            Q
          </Text>
        </View>
        

        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/R.png')} />
          <Text>
            R
          </Text>
        </View>
        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/S.png')} />
          <Text>
            S
          </Text>
        </View>
        
        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/T.png')} />
          <Text>
            T
          </Text>
        </View>
        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/U.png')} />
          <Text>
            U
          </Text>
        </View>
        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/Y.png')} />
          <Text>
            Y
          </Text>
        </View>
        <View>
          <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/Z.png')} />
          <Text>
            Z
          </Text>
        </View>
        
      </View>
      
    </View>
  )
}

export default NestedScreen1

const styles = StyleSheet.create({
  maincontainer:{
    backgroundColor: '#dcdcdc',
    display:"flex",
    flexDirection:"row",
    justifyContent:"center"
  },
  textcontainer:{
    alignItems:'center',
  },
  sectextcontainer:{
    marginTop:10,
    marginBottom:10,
    alignItems:'center',
  },
  mytext:{
    fontSize:20
  },
})