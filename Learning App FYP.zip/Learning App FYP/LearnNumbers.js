import { StyleSheet, Text, View,Image,Button } from 'react-native'
import React from 'react'
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import LearnAlphabets from './LearnAlphabets';

const Stack = createNativeStackNavigator();



const LearnNumbers = ({navigation}) => {
  
  return (
    
    
    <View>
        
      
      <View style={styles.textcontainer}>
        <Text style={styles.mytext}>Learn Numbers</Text>
      </View>
      <View style={styles.maincontainer}>
        <View>
        
            
          <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/NumbersLearn/1.png')} />
          <Text style={{fontSize:50}}>
            1
          </Text>
          
        </View>
        <View>
          <Image style={{width: 350, height: 350, top:60}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/NumbersLearn/2.png')} />
          <Text style={{fontSize:50}}>
            2
          </Text>
        </View>
        <View>
          <Image style={{width: 400, height: 400,top:-10}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/NumbersLearn/3.png')} />
          <Text style={{fontSize:50}}>
            3
          </Text>
        </View>
       
      </View>

      <View style={styles.maincontainer}>
      
        <View>
          <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/4.png')} />
          <Text style={{fontSize:50}}>
            4
          </Text>
        </View>
        <View>
          <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/5.png')} />
          <Text style={{fontSize:50}}>
            5
          </Text>
        </View>
        <View>
          <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/6.png')} />
          <Text style={{fontSize:50}}>
            6
          </Text>
        </View>
      </View>  
      <View style={styles.maincontainer}>
        <View>
          <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/7.png')} />
          <Text style={{fontSize:50}}>
            7
          </Text>
        </View>
        <View>
          <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/8.png')} />
          <Text style={{fontSize:50}}>
            8
          </Text>
        </View>
        
        <View>
          <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/9.png')} />
          <Text style={{fontSize:50}}>
            9
          </Text>
        </View>
      </View>
      <View style={styles.maincontainer}>
          <View>
            <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/10.png')} />
            <Text style={{fontSize:50}}>
              10
            </Text>
          </View>
       </View>
      
    </View>
  )
}

export default LearnNumbers

const styles = StyleSheet.create({
  maincontainer:{
    backgroundColor: '#dcdcdc',
    display:"flex",
    flexDirection:"row",
    justifyContent:"center"
  },
  textcontainer:{
    alignItems:'center',
  },
  sectextcontainer:{
    marginTop:10,
    marginBottom:10,
    alignItems:'center',
  },
  mytext:{
    fontSize:40
  },
})