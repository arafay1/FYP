import { StyleSheet, Text, View,Image } from 'react-native'
import React from 'react'
import LearnNumbers from './LearnNumbers'
import { createStackNavigator } from '@react-navigation/stack';
const Stack = createStackNavigator();
const LearnAlphabets = ({route}) => {
  
  return (
    <View>
        <Stack.Navigator>
            <Stack.Screen name="Numbers" component={LearnNumbers} />
            <Stack.Screen name="Alphabets" component={LearnAlphabets} />
        </Stack.Navigator>
      <View style={styles.textcontainer}>
        <Text style={styles.mytext}>Learn Alphabets</Text>
      </View>
      <View style={styles.maincontainer}>
        <View>
        
            
          <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/a.png')} />
          <Text style={{fontSize:50}}>
            A
          </Text>
          
        </View>
        <View>
          <Image style={{width: 350, height: 350, top:60}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/b.png')} />
          <Text style={{fontSize:50}}>
            B
          </Text>
        </View>
        <View>
          <Image style={{width: 400, height: 400,top:-10}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/C.png')} />
          <Text style={{fontSize:50}}>
            C
          </Text>
        </View>
       
      </View>

      <View style={styles.maincontainer}>
      
        <View>
          <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets//Alphabets/D.png')} />
          <Text style={{fontSize:50}}>
            D
          </Text>
        </View>
        <View>
          <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets//Alphabets/E.png')} />
          <Text style={{fontSize:50}}>
            E
          </Text>
        </View>
        <View>
          <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets//Alphabets/F.png')} />
          <Text style={{fontSize:50}}>
            F
          </Text>
        </View>
      </View>  
      <View style={styles.maincontainer}>
        <View>
          <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets//Alphabets/G.png')} />
          <Text style={{fontSize:50}}>
            G
          </Text>
        </View>
        <View>
          <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets//Alphabets/H.png')} />
          <Text style={{fontSize:50}}>
            H
          </Text>
        </View>
        
        <View>
          <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets//Alphabets/I.png')} />
          <Text style={{fontSize:50}}>
            I
          </Text>
        </View>
      </View>
      <View style={styles.maincontainer}>
          <View>
            <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets//Alphabets/K.png')} />
            <Text style={{fontSize:50}}>
              K
            </Text>
          </View>
          <View>
            <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets//Alphabets/L.png')} />
            <Text style={{fontSize:50}}>
              L
            </Text>
          </View>
          <View>
            <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets//Alphabets/M.png')} />
            <Text style={{fontSize:50}}>
              M
            </Text>
          </View>
       </View>
       <View style={styles.maincontainer}>
          <View>
            <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets//Alphabets/N.png')} />
            <Text style={{fontSize:50}}>
              N
            </Text>
          </View>
          <View>
            <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets//Alphabets/O.png')} />
            <Text style={{fontSize:50}}>
              O
            </Text>
          </View>
          <View>
            <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets//Alphabets/P.png')} />
            <Text style={{fontSize:50}}>
              P
            </Text>
          </View>
       </View>
       <View style={styles.maincontainer}>
          <View>
            <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets//Alphabets/Q.png')} />
            <Text style={{fontSize:50}}>
              Q
            </Text>
          </View>
          <View>
            <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets//Alphabets/R.png')} />
            <Text style={{fontSize:50}}>
              R
            </Text>
          </View>
          <View>
            <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets//Alphabets/S.png')} />
            <Text style={{fontSize:50}}>
              S
            </Text>
          </View>
       </View>
       <View style={styles.maincontainer}>
          <View>
            <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets//Alphabets/T.png')} />
            <Text style={{fontSize:50}}>
              T
            </Text>
          </View>
          <View>
            <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets//Alphabets/U.png')} />
            <Text style={{fontSize:50}}>
              U
            </Text>
          </View>
          <View>
            <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets//Alphabets/V.png')} />
            <Text style={{fontSize:50}}>
              V
            </Text>
          </View>
       </View>
       <View style={styles.maincontainer}>
          <View>
            <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets//Alphabets/W.png')} />
            <Text style={{fontSize:50}}>
              W
            </Text>
          </View>
          <View>
            <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets//Alphabets/Y.png')} />
            <Text style={{fontSize:50}}>
              Y
            </Text>
          </View>
          <View>
            <Image style={{width: 400, height: 400}} source = {require('E:/Documents/FYP/Coments/drawer/assets//Alphabets/Z.png')} />
            <Text style={{fontSize:50}}>
              Z
            </Text>
          </View>
       </View>
       
      
    </View>
  )
}

export default LearnAlphabets

const styles = StyleSheet.create({
  maincontainer:{
    backgroundColor: '#dcdcdc',
    display:"flex",
    flexDirection:"row",
    justifyContent:"center"
  },
  textcontainer:{
    alignItems:'center',
  },
  sectextcontainer:{
    marginTop:10,
    marginBottom:10,
    alignItems:'center',
  },
  mytext:{
    fontSize:40
  },
})