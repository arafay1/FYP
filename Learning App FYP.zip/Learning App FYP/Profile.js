import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity,
    TextInput,
    Button
  } from 'react-native';
import React, { useState } from 'react'


const Profile = ({route}) => {
    const [name,setName]=useState('');
    const [email,setEmail]=useState('');
    const [gender,setGender]=useState('');
    const [age,setAge]=useState('');
    const [shouldShow, setShouldShow] = useState(true);
    const [viewShow, setViewShow] = useState(false);
    function viewdata(){
      setShouldShow(!shouldShow)
      setViewShow(!viewShow)
        
    }
  return (
    <View style={styles.container}>
    <View style={styles.header}></View>
    <Image style={styles.avatar} source={{uri: 'https://bootdey.com/img/Content/avatar/avatar6.png'}}/>
    <View style={styles.body}>
      
      {shouldShow ? (
          <View style={styles.bodyContent}>
          <TextInput style={styles.myinput} value={name}
            onChange={e => setName(e.target.value)} placeholder='Enter Name' ></TextInput>
          <TextInput value={email}
            onChange={e => setEmail(e.target.value)} style={styles.myinput} placeholder='Email'></TextInput>
          <TextInput value={gender}
            onChange={e => setGender(e.target.value)} style={styles.myinput} placeholder='Gender'></TextInput>
          <TextInput value={age}
            onChange={e => setAge(e.target.value)} style={styles.myinput} placeholder='Age'></TextInput>
          <View style={{margin:10}}>
          </View>
          <Button
          title="Submit"
          onPress={() => setShouldShow(!shouldShow)}
          
        />
        </View>
        ) : null}
      
      {shouldShow ? (
          null
        ) : <View style={styles.secondContent}>
        <View style={styles.myflex}>
          <Text>Name:</Text>
          <Text>{name}</Text>
        </View>
        <View style={styles.myflex}>
          <Text>Email:</Text>
          <Text>{email}</Text>
        </View>
        <View style={styles.myflex}>
          <Text>Gender:</Text>
          <Text>{gender}</Text>
        </View>
        <View style={styles.myflex}>
          <Text>Age:</Text>
          <Text>{age}</Text>
        </View>
        
    </View>}

        
      
  </View>
</View>
  )
}

export default Profile

const styles = StyleSheet.create({
    myflex:{
      width:300,
      display:"flex",
      flexDirection:"row",
      justifyContent:"space-between",
      backgroundColor:"#fff",
      borderRadius:20,
      padding:10,
      marginTop:10
    },
    myinput:{
        backgroundColor:"#fff",
        borderRadius:10,
        padding:10,
        marginTop:5
    },
    mylastinput:{
      backgroundColor:"#fff",
        borderRadius:10,
        padding:10,
        margin:20
    },
    header:{
      backgroundColor: "#00BFFF",
      height:200,
    },
    avatar: {
      width: 130,
      height: 130,
      borderRadius: 63,
      borderWidth: 4,
      borderColor: "white",
      marginBottom:10,
      alignSelf:'center',
      position: 'absolute',
      marginTop:130
    },
    name:{
      fontSize:22,
      color:"#FFFFFF",
      fontWeight:'600',
    },
    body:{
      marginTop:40,
    },
    bodyContent: {
      flex: 1,
      alignItems: 'center',
      paddingTop:20
    },
    secondContent: {
      flex: 1,
      alignItems: 'center',
      paddingTop:10,
      marginTop:10
    },
    name:{
      fontSize:28,
      color: "#696969",
      fontWeight: "600"
    },
    info:{
      fontSize:16,
      color: "#00BFFF",
      marginTop:10
    },
    description:{
      fontSize:16,
      color: "#696969",
      marginTop:10,
      textAlign: 'center'
    }
  });