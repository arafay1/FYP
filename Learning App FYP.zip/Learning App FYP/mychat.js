import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity,
    TextInput,
    Button
  } from 'react-native';
import React, { useState } from 'react'


const ChatMine = ({navigation}) => {
  
  return (
      <View style={styles.myfirst}>
          <View style={styles.mycontainer}>
                <View style={styles.mybox}>
                    <Image style={{width: 80, height: 80}} source = {{uri:'https://bootdey.com/img/Content/avatar/avatar7.png'}} />
                </View>
                <View style={styles.mybox}>
                    <Text>John Doe</Text>
                    <Text>12:45am</Text>
                </View>
                <View style={styles.mythird}>
                    <Button onPress={() => navigation.navigate('SingleChat')}    title='View Messages'></Button>
                </View>
           </View>
           <View style={styles.mycontainer}>
                <View style={styles.mybox}>
                    <Image style={{width: 80, height: 80}} source = {{uri:'https://bootdey.com/img/Content/avatar/avatar6.png'}} />
                </View>
                <View style={styles.mybox}>
                    <Text>James Dan</Text>
                    <Text>9:45am</Text>
                </View>
                <View style={styles.mythird}>
                    <Button  onPress={() => navigation.navigate('SingleChat')} title='View Messages'></Button>
                </View>
           </View>
           <View style={styles.mycontainer}>
                <View style={styles.mybox}>
                    <Image style={{width: 80, height: 80}} source = {{uri:'https://bootdey.com/img/Content/avatar/avatar5.png'}} />
                </View>
                <View style={styles.mybox}>
                    <Text>Samy Jack</Text>
                    <Text>9:45am</Text>
                </View>
                <View style={styles.mythird}>
                    <Button onPress={() => navigation.navigate('SingleChat')} title='View Messages'></Button>
                </View>
           </View>
      </View>
    
    
  )
}

export default ChatMine

const styles = StyleSheet.create({
    myfirst:{
        alignItems:'center'
    },
    mycontainer:{
        alignItems:'center',
        flexDirection:'row',
        backgroundColor:"#fff",
        padding:10,
        margin:10,
        borderWidth:1
    },
    mythird:{
        marginLeft:50
    },
    mybox:{
        marginLeft:10
    }


  });