import * as React from 'react';
import { View, StyleSheet, Button,Text } from 'react-native';
import { Video, AVPlaybackStatus } from 'expo-av';
import Alright from "./assets/Video/alright.mp4"
import Goodmorning from "./assets/Video/goodmorning.mp4"
import Goodnight from "./assets/Video/goodnight.mp4"
import Congratulations from "./assets/Video/congratulations.mp4"
import doenglish from "./assets/Video/doenglish.mp4"
import didpassfail from "./assets/Video/didpassfail.mp4"
import callambulance from "./assets/Video/callambulance.mp4"
import Aoa from "./assets/Video/aoa.mp4"
import Beaware from "./assets/Video/beaware.mp4"
import Close from "./assets/Video/close.mp4"
import Come from "./assets/Video/come.mp4"
import Help from "./assets/Video/help.mp4"

export default function SecMain() {
  const video = React.useRef(null);
  const [status, setStatus] = React.useState({});
  const [btndisplay,setBtndisplay]=React.useState('none');
  const [btntitle,setBtntitle]=React.useState('Load More');
  const [secondbtndisplay,setSecondBtndisplay]=React.useState('none');
  const [secondbtntitle,setSecondBtntitle]=React.useState('Load More');
  function displaybtn(){
    setBtndisplay(!btndisplay);
    setBtntitle(!btntitle)
  }
  function Seconddisplaybtn(){
    setSecondBtndisplay(!secondbtndisplay);
    setSecondBtntitle(!secondbtntitle)
  }
  return (
    <View style={styles.maincont}>
      <View style={styles.textcontainer}>
      <Text style={styles.mytext}>Learn Words</Text>
      </View>
      <View style={styles.container}>
        
            <View>
              <Video
                ref={video}
                style={styles.video}
                source={Alright}
                useNativeControls
                resizeMode="contain"
                isLooping
                onPlaybackStatusUpdate={status => setStatus(() => status)}
              />
              
            </View>
            <View>
              <Video
                ref={video}
                style={styles.video}
                source={Beaware}
                useNativeControls
                resizeMode="contain"
                isLooping
                onPlaybackStatusUpdate={status => setStatus(() => status)}
              />
              
            </View>
            <View>
              <Video
                ref={video}
                style={styles.video}
                source={Aoa}
                useNativeControls
                resizeMode="contain"
                isLooping
                onPlaybackStatusUpdate={status => setStatus(() => status)}
              />
              
            </View>
      </View>
      <View style={{display:btndisplay? "none":"flex"}}>
      <View style={styles.container}>
            <View>
              <Video
                ref={video}
                style={styles.video}
                source={Goodmorning}
                useNativeControls
                resizeMode="contain"
                isLooping
                onPlaybackStatusUpdate={status => setStatus(() => status)}
              />
              
            </View>
            <View>
              <Video
                ref={video}
                style={styles.video}
                source={Goodnight}
                useNativeControls
                resizeMode="contain"
                isLooping
                onPlaybackStatusUpdate={status => setStatus(() => status)}
              />
              
            </View>
            <View>
              <Video
                ref={video}
                style={styles.video}
                source={Congratulations}
                useNativeControls
                resizeMode="contain"
                isLooping
                onPlaybackStatusUpdate={status => setStatus(() => status)}
              />
              
            </View>
      </View>
      </View>
      <View style={styles.btncontainer}>
        <Button title={btntitle? "Load More":"Load Less"} onPress={displaybtn}></Button>
      </View>
      <View style={styles.sectextcontainer}>
      <Text style={styles.mytext}>Learn Sentences</Text>
      </View>
      <View style={styles.container}>
            <View>
              <Video
                ref={video}
                style={styles.video}
                source={Close}
                useNativeControls
                resizeMode="contain"
                isLooping
                onPlaybackStatusUpdate={status => setStatus(() => status)}
              />
              
            </View>
            <View>
              <Video
                ref={video}
                style={styles.video}
                source={Come}
                useNativeControls
                resizeMode="contain"
                isLooping
                onPlaybackStatusUpdate={status => setStatus(() => status)}
              />
              
            </View>
            <View>
              <Video
                ref={video}
                style={styles.video}
                source={Help}
                useNativeControls
                resizeMode="contain"
                isLooping
                onPlaybackStatusUpdate={status => setStatus(() => status)}
              />
              
            </View>
      </View>
      <View style={{display:secondbtndisplay? "none":"flex"}}>
      <View style={styles.container}>
            <View>
              <Video
                ref={video}
                style={styles.video}
                source={doenglish}
                useNativeControls
                resizeMode="contain"
                isLooping
                onPlaybackStatusUpdate={status => setStatus(() => status)}
              />
              
            </View>
            <View>
              <Video
                ref={video}
                style={styles.video}
                source={didpassfail}
                useNativeControls
                resizeMode="contain"
                isLooping
                onPlaybackStatusUpdate={status => setStatus(() => status)}
              />
              
            </View>
            <View>
              <Video
                ref={video}
                style={styles.video}
                source={callambulance}
                useNativeControls
                resizeMode="contain"
                isLooping
                onPlaybackStatusUpdate={status => setStatus(() => status)}
              />
              
            </View>
      </View>
      </View>
      <View style={styles.btncontainer}>
        <Button title={secondbtntitle? "Load More":"Load Less"} onPress={Seconddisplaybtn}></Button>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  textcontainer:{
    alignItems:'center',
  },
  sectextcontainer:{
    marginTop:10,
    alignItems:'center',
  },
  mytext:{
    fontSize:20
  },
  maincont:{
    backgroundColor: '#ecf0f1',
  },
  btncontainer:{
    alignItems:'center'
  },  
  container: {
    flex: 1,
    justifyContent: 'center',
    flexDirection:'row',
    justifyContent:'space-between',
    margin:20
  },
  video: {
    alignSelf: 'center',
    width: 320,
    height: 200,
  },
  buttons: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
