import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity,
    TextInput,
    Button
  } from 'react-native';
import React, { useState } from 'react'
import axios from 'axios';

const SignUp = ({navigation}) => {
    const [name,setName]=useState('');
    const [email,setEmail]=useState('');
    const [password,setPassword]=useState('');
    const [shouldShow, setShouldShow] = useState(true);
    const [viewShow, setViewShow] = useState(false);
    function viewdata(){
        alert("Success")
        
    }
    const postUser=()=>{
      // console.log("Email:"+validate(email));
      // console.log("Length:"+checklength(password));
        if((validate(email)) && (checklength(password))){
          axios({
            method:'POST',
            url:'http://localhost:3000/addpatient',
            data:{
              name:name,
              email:email,
              password:password
            },
            headers:{
              "Accept": "application/json",
              "Content-Type": "application/json"
            }
          })
          .then(function (response) {
            console.log("response", JSON.stringify(response.data))
          })
          .catch(function (error) {
            console.log("error", error)
          })
          navigation.navigate('SignIn');
        }
        else{
          alert("Provide Valid Email and Password");
        }
       
      }
      const checklength=(text)=>{
        if(password.length>=5){
          setPassword(text);
          return true;
        }
        else{
          setPassword(text);
          return false;
        }
      }
     const validate = (text) => {
        // console.log(text);
        let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w\w+)+$/;
        if (reg.test(text) === false) {
          // console.log("Email is Not Correct");
          setEmail(text);
          return false;
        }
        else {
          setEmail(text);
          // console.log("Email is Correct");
          return true;
        }
      }
  return (
    <View style={styles.mainmaincontainer}>
      <View>
                  <Image style={{width: 450, height: 300,position:'absolute', top:100, left:200,borderTopRightRadius: 20,borderBottomRightRadius: 20,borderBottomLeftRadius: 20,borderTopLeftRadius: 20,} } source = {require('E:/Documents/FYP/Coments/drawer/assets/Logo/signup.jpg')} />
                  <View style={{top:430,left:205,fontWeight: 'bold',fontSize:25,fontStyle: 'italic'}}>Sign up to be the part of this great journey</View>
          </View>
      <View style={styles.maincontainer}>
      <View>
                  <Image style={{width: 200, height: 200}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Logo/signs.png')} />
                  <View style={{left:50,fontWeight: 'bold'}}>I CAN SPEAK</View>
          </View>
        <View style={styles.signupcontainer}>
                
                
                <View style={styles.bodyContent}>
                <TextInput style={styles.loginFormTextInput} value={name}
                    onChange={e => setName(e.target.value)} placeholder='Enter Username' ></TextInput>
                <TextInput value={email}
                    onChangeText={(text) => validate(text)} style={styles.loginFormTextInput} placeholder='Email'></TextInput>
                
                <TextInput value={password}
                    onChangeText={(text) => checklength(text)} style={styles.loginFormTextInput}placeholder='Password'></TextInput>
                <View style={{margin:10}}>
                </View>
                <Button
                title="SignUp"
                onPress={() => postUser()}
                buttonStyle={styles.loginButton}
                />
                </View>
            </View>
      </View>
      </View>
  )
}

export default SignUp

const styles = StyleSheet.create({
    maincontainer:{
      position:'absolute',
      top:50,
      left:800,
      backgroundColor: '#dcdcdc',
      alignItems:'center',
      width:300
    },
    signupcontainer:{
        display:'flex',
        alignItems:'center',
        flexDirection:'column',
        width:500
    },
    bodyContent: {
        flex: 1,
        alignItems: 'center',
        paddingTop:20
    },
    loginFormTextInput: {
      height: 43,
      fontSize: 14,
      borderRadius: 5,
      borderWidth: 1,
      borderColor: "#eaeaea",
      backgroundColor: "#fafafa",
      paddingLeft: 10,
      marginTop: 5,
      marginBottom: 5,
    },loginButton: {
      backgroundColor: "#3897f1",
      borderRadius: 5,
      height: 45,
      marginTop: 10,
      width: 550,
      alignItems: "center"
    },
    myinput:{
        backgroundColor:"#fff",
        borderRadius:5,
        padding:5,
        marginTop:5,
        borderWidth:  1
    },
  });