import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity,
    TextInput,
    Button
  } from 'react-native';
import React, { useState } from 'react'


const ChatMine = ({navigation}) => {
    
    const [mydisplay,setDisplay]=useState('none')
    const [message,setMessage]=useState('');
    const [distext,setDistext]=useState('none');

    function display(){
        setDistext(!distext);
        console.log(message);
    }
  
  return (
      <View style={styles.mymain}>
            <View style={styles.myfirst}>
                    <View style={styles.left}>
                        <Text style={styles.textl}>
                            Hi
                        </Text>
                    </View>
                    <View style={styles.right}>
                        <Text style={styles.textr}>
                            Hi
                        </Text>
                    </View>
                    <View style={styles.left}>
                        <Text style={styles.textls}>
                            How are you fine?
                        </Text>
                    </View>
                    <View style={styles.right}>
                        <Text style={styles.textrs}>
                            Me Fine
                        </Text>
                    </View>

                    <View style={styles.right}>
                    <View style={{display:distext? "none":"flex"}}>
                        <Text style={styles.textnew}>
                            {message}
                        </Text>
                    </View>
                    </View>
                    
                    <View style={styles.mylast}>
                        <TextInput style={styles.mytxtin} onChange={e => setMessage(e.target.value)}  placeholder='Enter text Here'></TextInput>
                        <Button title='Send' onPress={() => display()} ></Button>
                    </View>
                </View>

      </View>
      
    
    
  )
}

export default ChatMine

const styles = StyleSheet.create({
    mybtn:{
        alignItems:'flex-end'
    },  
    mylast:{
        alignItems:'center',
        flexDirection:'row',
        marginTop:90
    },
    mytxtin:{
        width:240,
        alignItems:'left',
        padding:5,
        borderWidth:2
    },
    mymain:{
        alignItems:'center'
    },
    myfirst:{
        alignItems:'center',
        backgroundColor:'#fff',
        width:300
    },
    left:{
        alignItems:'left',
        width:300,
        
    },
    textls:{
        width:150,
        marginTop:20,
        padding:10,
        borderRadius:5,
        color:'white',
        backgroundColor:'blue'
    },
    textl:{
        width:50,
        padding:10,
        borderRadius:5,
        color:'white',
        backgroundColor:'blue'
    },
    right:{
        alignItems:'end',
        width:300,
        
    },
    textnew:{
        marginTop:20,
        width:100,
        padding:10,
        borderRadius:5,
        color:'white',
        backgroundColor:'blue'
    },
    textrs:{
        marginTop:20,
        width:100,
        padding:10,
        borderRadius:5,
        color:'white',
        backgroundColor:'blue'
    },
    textr:{
        width:50,
        padding:10,
        borderRadius:5,
        color:'white',
        backgroundColor:'blue'
    }
    


  });