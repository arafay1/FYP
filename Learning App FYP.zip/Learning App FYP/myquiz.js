import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity,
    TextInput,
    Button
  } from 'react-native';
import React, { useState } from 'react'
import { RadioButton } from 'react-native-paper';

const Quiz = ({route}) => {
  const [checked, setChecked] = React.useState('');
  const [second, setSecond] = React.useState('');
  const [third, setThird] = React.useState('');
  const [result,setResult]=React.useState(0);
  var count=0;
  function display(){
    if(checked=="first"){
      count=count+1;
      
    }
    if(second=="third"){
      count=count+1;
     
    }
    if(third=="sixth"){
      count=count+1;
     
    }
    
    setResult(count)
  }
  return (
    <View style={styles.mycontainer}>
        
        <View>
            <Text style={styles.mytext}>
                What is sign used for one?
            </Text>
            
            <View style={styles.myseccontainer}>
                <View>
                  <RadioButton
                  value="first"
                  status={ checked === 'first' ? 'checked' : 'unchecked' }
                  onPress={() => setChecked('first')}
                  />
                  <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/1.png')} />
                </View>
                <View>
                    <RadioButton
                    value="second"
                    status={ checked === 'second' ? 'checked' : 'unchecked' }
                    onPress={() => setChecked('second')}
                    />
                    <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/2.png')} />
                </View>
            
            </View>

            <Text style={styles.mytext}>
                What is sign used for A?
            </Text>

            <View style={styles.myseccontainer}>
                <View>
                  <RadioButton
                  value="third"
                  status={ second === 'third' ? 'checked' : 'unchecked' }
                  onPress={() => setSecond('third')}
                  />
                  <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/a.png')} />
                </View>
                <View>
                    <RadioButton
                    value="fourth"
                    status={ second === 'fourth' ? 'checked' : 'unchecked' }
                    onPress={() => setSecond('fourth')}
                    />
                    <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Alphabets/b.png')} />
                </View>
            
            </View>

            <Text style={styles.mytext}>
                What is sign used for 6?
            </Text>

            <View style={styles.myseccontainer}>
                <View>
                  <RadioButton
                  value="first"
                  status={ third === 'fifth' ? 'checked' : 'unchecked' }
                  onPress={() => setThird('fifth')}
                  />
                  <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/9.png')} />
                </View>
                <View>
                    <RadioButton
                    value="second"
                    status={ third === 'sixth' ? 'checked' : 'unchecked' }
                    onPress={() => setThird('sixth')}
                    />
                   <Image style={{width: 100, height: 100}} source = {require('E:/Documents/FYP/Coments/drawer/assets/Numbers/6.png')} />
                </View>

            </View>
            
            <View style={styles.mybtncontainer}>
              <TouchableOpacity style={styles.quizbtn} onPress={display}>
              <Text style={styles.mysub}>Submit</Text>
              </TouchableOpacity>
            </View>
            <View>
              <Text>Total Questions</Text>
              <Text>3</Text>
              <Text>Correct Answers</Text>
              <Text>{result}</Text>
              
            </View>
        </View>
    </View>
  )
}

export default Quiz

const styles = StyleSheet.create({
    mytext:{
      fontSize:20
    },
    mycontainer:{
        textAlign:'center',
    },
    myseccontainer:{
        display:'flex',
        flexDirection:'row',
        justifyContent: 'center'
    },
    mybtncontainer:{
      
      backgroundColor:'black',
      
      marginLeft:580,
      
      width:200
    },
    mysub:{
      color:'white',
      paddingLeft:60,
      paddingTop:5
    },
    quizbtn:{
      width:120,
      height:30,
      textAlign:'center'
    }


  });